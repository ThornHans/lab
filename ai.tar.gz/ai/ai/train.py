from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer


class Bot:
	"""docstring for Bot"""
	chatbot = ChatBot("LAKOUYU ChatBot")
	trained = False
	


	
	def train(self):
		
	
		self.chatbot.set_trainer(ChatterBotCorpusTrainer)
		self.chatbot.train("chatterbot.corpus.english")
		self.trained = True

	def get_training_status(self):
		return self.trained
	# def get_ans(self,input_data):
	# 	return self.chatbot.get_response(input_data)

