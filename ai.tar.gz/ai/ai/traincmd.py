from  train import Bot


bot = Bot()
bot.train()
