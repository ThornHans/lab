from django.views.generic.base import TemplateView
from django.views.generic import View
from django.http import JsonResponse
from ai.train import Bot
#from chatterbot.ext.django_chatterbot import settings
from django.shortcuts import render 
from django.views.decorators.csrf import csrf_exempt 

import json



class BotView(View):
    """
    Provide an API endpoint to interact with ChatterBot.
    """
       
  
    @csrf_exempt
    def post(request):
        #bot = Bot()
        """
        Return a response to the statement in the posted data.
        * The JSON data should contain a 'text' attribute.
        """
        #if request.is_ajax and request.method == "POST":
        ##msg = json.loads(request.POST.get('data'))
        msg = json.loads(request.body.decode('utf-8'))
        
        if not msg:
             msg = 'fuck'
        #if Bot.get_training_status(Bot):
        response = Bot.chatbot.get_response(msg)

        if not response: 
            response = 'fuck'
            return JsonResponse(response,safe=False)
        #else: response = "wait...plz"
       
    
        response_data = response.serialize()
        


        
        return JsonResponse(response_data,safe=False)




   
    
      
    # Create your views here. 
    def ai(request): 
          
        # render function takes argument  - request 
        # and return HTML as response 
        return render(request, "ai.html") 









