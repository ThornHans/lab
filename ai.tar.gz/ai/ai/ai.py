
#from chatterbot import ChatBot
# from chatterbot.trainers import ChatterBotCorpusTrainer


from django.views.generic import View
from django.template.response import TemplateResponse


def ai(request):
    return TemplateResponse(request, 'ai/templates/ai.html')
#from chatterbot.ext.django_chatterbot import settings











